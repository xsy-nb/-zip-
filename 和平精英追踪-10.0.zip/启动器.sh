#!/bin/bash

if [ "$(id -u)" -ne 0 ]; then
    echo "[-] 请用ROOT权限执行! "
    exit 1
fi

if [[ "${0%/*}" == *bin.mt.plus/temp* ]]; then
    echo "[-] 请勿在压缩包内执行! "
    exit 1
fi

if [ ! -f injector ] || [ ! -f libWn.so ]; then
    echo "[-] 未找到\"libWn.so\"或\"injector\"! "
    exit 1
fi

cp -f injector /data/local/tmp/
cp -f libWn.so /data/local/tmp/

chmod +x /data/local/tmp/injector
chmod +x /data/local/tmp/libWn.so

# am start -n com.tencent.tmgp.pubgmhd/com.epicgames.ue4.SplashActivity &>/dev/null

/data/local/tmp/injector --pkg com.tencent.tmgp.pubgmhd --sleep 10.0