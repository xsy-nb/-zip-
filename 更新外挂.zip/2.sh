#!/system/bin/sh
# 源目录
TARGET_DIR="/data/adb/1/和平/"
# 输出目录
DEST_XSJ="/data/adb/1/和平/小烧鸡内核"
DEST_HLW="/data/adb/1/和平/葫芦娃内核"
DEST_LV="/data/adb/1/和平/lv内核"
DEST_BIAN="/data/adb/1/和平/避案内部版"
DEST_FLY="/data/adb/1/和平/超级飞侠"
DEST_PMK="/data/adb/1/和平/贫民窟免费纯c"
DEST_HPJY="/data/local/tmp"
DEST_DY="/data/local/tmp"
DEST_DRIVER="/data/adb/1/和平/驱动文件"  # 新增驱动文件目录
DEST_CLEAN="/data/adb/1/和平/清理文件"   # 新增清理文件目录
# 下载链接
URL_XSJ="https://github.com/xsy-nb/-zip-/raw/refs/heads/main/小烧鸡公益内核13.5.zip"
URL_HLW="https://github.com/xsy-nb/-zip-/raw/refs/heads/main/葫芦娃公益内核3.1.zip"
URL_LV="https://github.com/xsy-nb/-zip-/raw/refs/heads/main/LV-8.0[追踪版].zip"
URL_BIAN="https://github.com/xsy-nb/-zip-/raw/refs/heads/main/避案内部版5.2.zip"
URL_FLY="https://github.com/xsy-nb/-zip-/raw/refs/heads/main/超级飞侠v1.2.zip"
URL_PMK="https://github.com/xsy-nb/-zip-/raw/refs/heads/main/贫民窟免费内核-2.4.zip"
URL_HPJY="https://github.com/xsy-nb/-zip-/raw/refs/heads/main/和平精英追踪-10.0.zip"
URL_DY="https://github.com/xsy-nb/-zip-/raw/refs/heads/main/26.03.11DY追踪免费版.zip"
URL_DRIVER="https://github.com/xsy-nb/-zip-/blob/main/驱动文件.zip"  # 新增驱动文件链接
URL_CLEAN="https://github.com/xsy-nb/-zip-/raw/refs/heads/main/清理.zip" # 新增清理文件链接
# 颜色定义
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 检查目录，不存在则创建
if [ ! -d "$TARGET_DIR" ]; then
    echo -e "${YELLOW}📁 目录不存在：$TARGET_DIR，正在创建...${NC}"
    mkdir -p "$TARGET_DIR" || { echo -e "${RED}❌ 目录创建失败${NC}"; exit 1; }
fi
cd "$TARGET_DIR" || { echo -e "${RED}❌ 进入目录失败${NC}"; exit 1; }

# 检查curl是否存在
check_curl() {
    if ! command -v curl &> /dev/null; then
        echo -e "${RED}❌ 未检测到curl，请先安装curl工具${NC}"
        exit 1
    fi
}

# curl下载函数（带进度条+文件校验）
download_file() {
    local url="$1"
    local save_name="$2"
    echo -e "${YELLOW}📥 开始下载：$save_name${NC}"
    # -# 进度条模式  -L 跟随重定向  --insecure 忽略证书  -o 输出文件
    if curl -# -L --insecure "$url" -o "$save_name"; then
        # 检测下载文件是否有效（非空）
        if [ -s "$save_name" ]; then
            echo -e "\n${GREEN}✅ 下载成功：$save_name${NC}"
            return 0
        else
            echo -e "\n${RED}❌ 下载文件为空，链接无效或文件不存在${NC}"
            rm -f "$save_name"
            return 1
        fi
    else
        echo -e "\n${RED}❌ 下载失败，请检查网络或链接${NC}"
        rm -f "$save_name"
        return 1
    fi
}

# 处理小烧鸡公益内核
process_xsj() {
    echo -e "\n${BLUE}===== 处理 小烧鸡公益内核 =====${NC}"
    check_curl
    mkdir -p "$DEST_XSJ"
    local zip_name="小烧鸡公益内核13.5.zip"
    if [ ! -f "$zip_name" ]; then
        download_file "$URL_XSJ" "$zip_name" || return 1
    fi
    unzip -o "$zip_name" -d "$DEST_XSJ" &> /dev/null
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ 解压成功 → $DEST_XSJ${NC}"
        rm -f "$zip_name"
        echo -e "${GREEN}🗑️ 已删除原压缩包${NC}"
    else
        echo -e "${RED}❌ 解压失败${NC}"
        rm -f "$zip_name"
    fi
}

# 处理葫芦娃公益内核
process_hlw() {
    echo -e "\n${BLUE}===== 处理 葫芦娃公益内核 =====${NC}"
    check_curl
    mkdir -p "$DEST_HLW"
    local zip_name="葫芦娃公益内核3.1.zip"
    if [ ! -f "$zip_name" ]; then
        download_file "$URL_HLW" "$zip_name" || return 1
    fi
    unzip -o "$zip_name" -d "$DEST_HLW" &> /dev/null
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ 解压成功 → $DEST_HLW${NC}"
        rm -f "$zip_name"
        echo -e "${GREEN}🗑️ 已删除原压缩包${NC}"
    else
        echo -e "${RED}❌ 解压失败${NC}"
        rm -f "$zip_name"
    fi
}

# 处理LV内核 / 追踪版
process_lv() {
    echo -e "\n${BLUE}===== 处理 LV内核 / 追踪版 =====${NC}"
    check_curl
    mkdir -p "$DEST_LV"
    local zip_name="LV-8.0[追踪版].zip"
    local lv_zip_found=0
    if [ ! -f "$zip_name" ]; then
        download_file "$URL_LV" "$zip_name" || return 1
    fi
    if [ -f "$zip_name" ]; then
        lv_zip_found=1
        echo -e "${GREEN}找到lv内核zip：$zip_name${NC}"
        unzip -o "$zip_name" -d "$DEST_LV" &> /dev/null
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}✅ 解压成功 → $DEST_LV${NC}"
            rm -f "$zip_name"
            echo -e "${GREEN}🗑️ 已删除原zip${NC}"
        else
            echo -e "${RED}❌ 解压失败${NC}"
            rm -f "$zip_name"
        fi
    fi
    if [ $lv_zip_found -eq 1 ]; then
        echo -e "\n${GREEN}已检测到LV内核zip，跳过文件复制${NC}"
        return 0
    fi
    # 兼容原文件复制逻辑
    echo -e "\n${YELLOW}未找到lv内核*.zip，开始检测 lv / 追踪版 文件${NC}"
    local lv_file_found=0
    for file in lv*[0-9]*; do
        if [ -f "$file" ]; then
            lv_file_found=1
            echo -e "${GREEN}找到：$file${NC}"
            cp -f "$file" "$DEST_LV/" && rm -f "$file"
            echo -e "${GREEN}✅ 已复制并删除源文件${NC}"
        fi
    done
    for file in *追踪版*; do
        if [ -f "$file" ]; then
            lv_file_found=1
            echo -e "${GREEN}找到追踪版：$file${NC}"
            cp -f "$file" "$DEST_LV/" && rm -f "$file"
            echo -e "${GREEN}✅ 已复制并删除源文件${NC}"
        fi
    done
    if [ $lv_file_found -eq 0 ]; then
        echo -e "${RED}未下载 lv 内核或追踪版文件${NC}"
    fi
}

# 处理避案内部版
process_bian() {
    echo -e "\n${BLUE}===== 处理 避案内部版 =====${NC}"
    check_curl
    mkdir -p "$DEST_BIAN"
    local zip_name="避案内部版5.2.zip"
    local bian_found=0
    if [ ! -f "$zip_name" ]; then
        download_file "$URL_BIAN" "$zip_name" || return 1
    fi
    if [ -f "$zip_name" ]; then
        bian_found=1
        echo -e "${GREEN}找到：$zip_name${NC}"
        unzip -o "$zip_name" -d "$DEST_BIAN" &> /dev/null
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}✅ 解压成功 → $DEST_BIAN${NC}"
            rm -f "$zip_name"
            echo -e "${GREEN}🗑️ 已删除原压缩包${NC}"
        else
            echo -e "${RED}❌ 解压失败${NC}"
            rm -f "$zip_name"
        fi
    fi
    if [ $bian_found -eq 0 ]; then
        echo -e "${RED}未找到 避案内部版 相关zip文件${NC}"
    fi
}

# 处理超级飞侠
process_fly() {
    echo -e "\n${BLUE}===== 处理 超级飞侠 =====${NC}"
    check_curl
    mkdir -p "$DEST_FLY"
    local zip_name="超级飞侠v1.2.zip"
    local fly_found=0
    if [ ! -f "$zip_name" ]; then
        download_file "$URL_FLY" "$zip_name" || return 1
    fi
    if [ -f "$zip_name" ]; then
        fly_found=1
        echo -e "${GREEN}找到：$zip_name${NC}"
        unzip -o "$zip_name" -d "$DEST_FLY" &> /dev/null
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}✅ 解压成功 → $DEST_FLY${NC}"
            rm -f "$zip_name"
            echo -e "${GREEN}🗑️ 已删除原压缩包${NC}"
        else
            echo -e "${RED}❌ 解压失败${NC}"
            rm -f "$zip_name"
        fi
    fi
    if [ $fly_found -eq 0 ]; then
        echo -e "${RED}未找到 超级飞侠 相关zip文件${NC}"
    fi
}

# 处理贫民窟免费纯c
process_pmk() {
    echo -e "\n${BLUE}===== 处理 贫民窟免费纯c =====${NC}"
    check_curl
    mkdir -p "$DEST_PMK"
    local zip_name="贫民窟免费内核-2.4.zip"
    local pmk_found=0
    if [ ! -f "$zip_name" ]; then
        download_file "$URL_PMK" "$zip_name" || return 1
    fi
    if [ -f "$zip_name" ]; then
        pmk_found=1
        echo -e "${GREEN}找到：$zip_name${NC}"
        unzip -o "$zip_name" -d "$DEST_PMK" &> /dev/null
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}✅ 解压成功 → $DEST_PMK${NC}"
            rm -f "$zip_name"
            echo -e "${GREEN}🗑️ 已删除原压缩包${NC}"
        else
            echo -e "${RED}❌ 解压失败${NC}"
            rm -f "$zip_name"
        fi
    fi
    if [ $pmk_found -eq 0 ]; then
        echo -e "${RED}未找到 贫民窟免费纯c 相关zip文件${NC}"
    fi
}

# 处理和平精英追踪
process_hpjy() {
    echo -e "\n${BLUE}===== 处理 和平精英追踪 =====${NC}"
    check_curl
    mkdir -p "$DEST_HPJY"
    local zip_name="和平精英追踪-10.0.zip"
    local hpjy_found=0
    if [ ! -f "$zip_name" ]; then
        download_file "$URL_HPJY" "$zip_name" || return 1
    fi
    if [ -f "$zip_name" ]; then
        hpjy_found=1
        echo -e "${GREEN}找到：$zip_name${NC}"
        unzip -o "$zip_name" -d "$DEST_HPJY" &> /dev/null
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}✅ 解压成功 → $DEST_HPJY${NC}"
            rm -f "$zip_name"
            echo -e "${GREEN}🗑️ 已删除原压缩包${NC}"
        else
            echo -e "${RED}❌ 解压失败${NC}"
            rm -f "$zip_name"
        fi
    fi
    if [ $hpjy_found -eq 0 ]; then
        echo -e "${RED}未找到 和平精英追踪 相关zip文件${NC}"
    fi
}

# 处理数字+dy追踪免费版
process_dy() {
    echo -e "\n${BLUE}===== 处理 数字+dy追踪免费版 =====${NC}"
    check_curl
    mkdir -p "$DEST_DY"
    local zip_name="26.03.11DY追踪免费版.zip"
    local dy_found=0
    if [ ! -f "$zip_name" ]; then
        download_file "$URL_DY" "$zip_name" || return 1
    fi
    if [ -f "$zip_name" ]; then
        dy_found=1
        echo -e "${GREEN}找到：$zip_name${NC}"
        unzip -o "$zip_name" -d "$DEST_DY" &> /dev/null
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}✅ 解压成功 → $DEST_DY${NC}"
            rm -f "$zip_name"
            echo -e "${GREEN}🗑️ 已删除原压缩包${NC}"
        else
            echo -e "${RED}❌ 解压失败${NC}"
            rm -f "$zip_name"
        fi
    fi
    if [ $dy_found -eq 0 ]; then
        echo -e "${RED}未找到 数字+dy追踪免费版 相关zip文件${NC}"
    fi
}

# 新增：处理驱动文件
process_driver() {
    echo -e "\n${BLUE}===== 处理 驱动文件 =====${NC}"
    check_curl
    mkdir -p "$DEST_DRIVER"
    local zip_name="驱动文件.zip"
    if [ ! -f "$zip_name" ]; then
        download_file "$URL_DRIVER" "$zip_name" || return 1
    fi
    unzip -o "$zip_name" -d "$DEST_DRIVER" &> /dev/null
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ 解压成功 → $DEST_DRIVER${NC}"
        rm -f "$zip_name"
        echo -e "${GREEN}🗑️ 已删除原压缩包${NC}"
    else
        echo -e "${RED}❌ 解压失败${NC}"
        rm -f "$zip_name"
    fi
}

# 新增：处理清理文件
process_clean() {
    echo -e "\n${BLUE}===== 处理 清理文件 =====${NC}"
    check_curl
    mkdir -p "$DEST_CLEAN"
    local zip_name="清理.zip"
    if [ ! -f "$zip_name" ]; then
        download_file "$URL_CLEAN" "$zip_name" || return 1
    fi
    unzip -o "$zip_name" -d "$DEST_CLEAN" &> /dev/null
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ 解压成功 → $DEST_CLEAN${NC}"
        rm -f "$zip_name"
        echo -e "${GREEN}🗑️ 已删除原压缩包${NC}"
    else
        echo -e "${RED}❌ 解压失败${NC}"
        rm -f "$zip_name"
    fi
}

# 一键执行所有（含新增的驱动+清理文件）
process_all() {
    echo -e "${YELLOW}🚀 一键执行所有文件处理...${NC}"
    check_curl
    process_xsj
    process_hlw
    process_lv
    process_bian
    process_fly
    process_pmk
    process_hpjy
    process_dy
    process_driver  # 新增执行驱动文件处理
    process_clean   # 新增执行清理文件处理
}

# 菜单界面
clear
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}        内核自动解压脚本菜单           ${NC}"
echo -e "${BLUE}==== curl进度条+下载+解压 一体化 ====${NC}"
echo -e "${BLUE}========================================${NC}"
echo -e "1) ${GREEN}小烧鸡公益内核${NC}"
echo -e "2) ${GREEN}葫芦娃公益内核${NC}"
echo -e "3) ${GREEN}LV内核 / 追踪版${NC}"
echo -e "4) ${GREEN}避案内部版${NC}"
echo -e "5) ${GREEN}超级飞侠${NC}"
echo -e "6) ${GREEN}贫民窟免费纯c${NC}"
echo -e "7) ${GREEN}和平精英追踪${NC}"
echo -e "8) ${GREEN}数字+dy追踪免费版${NC}"
echo -e "9) ${GREEN}驱动文件${NC}"  # 新增9选项
echo -e "10)${GREEN}清理文件${NC}"   # 新增10选项
echo -e "11)${GREEN}✅ 一键执行所有${NC}"                     # 原9→11一键执行
echo -e "0) ${RED}退出${NC}"
echo -e "${BLUE}========================================${NC}"
echo -n "请输入选项 [0-11]："
read -r choice

# 选项执行
case $choice in
    1) process_xsj ;;
    2) process_hlw ;;
    3) process_lv ;;
    4) process_bian ;;
    5) process_fly ;;
    6) process_pmk ;;
    7) process_hpjy ;;
    8) process_dy ;;
    9) process_driver ;;  # 新增9选项执行
    10) process_clean ;; # 新增10选项执行
    11) process_all ;;   # 原9→11一键执行所有
    0) echo -e "\n${YELLOW}👋 退出脚本${NC}"; exit 0 ;;
    *) echo -e "\n${RED}❌ 输入错误，请输入 0-11 之间的数字${NC}" ;;
esac

echo -e "\n${GREEN}🎉 全部操作完成！${NC}"
exit 0
